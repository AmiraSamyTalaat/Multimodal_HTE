# Paper 1: Multimodal heterogeneous treatment-effect benchmarking

This archive provides Python source, original locked experiment configurations, an experiment chronology, aggregate results, and additional analyses accompanying the paper *Multimodal heterogeneous treatment-effect benchmarking identifies the value of clinical effect models and regularized estimation*.

## Data sources

Pretreatment I-SPY2 covariates were obtained from public GEO records GSE194040 (transcriptomics) and GSE196093 (RPPA). The analysis contains 736 linked participants and 3 clinical, 702 pathway and 139 RPPA features. Treatment assignments and binary outcomes were simulated; observed I-SPY2 trial treatments and pathologic responses were not treated as benchmark labels. Public accession numbers and data preparation scripts are given in `original/00_CONFIG/data_sources.yaml` and `original/01_CODE/scripts/`.

The archive deliberately contains **no person-level input matrices, patient identifiers, individual potential outcomes, or individual model predictions**. A full model rerun requires the original public GEO inputs and the preprocessing workflow; preserved aggregate results can be inspected without downloading participant data.

## Contents

- `original/00_CONFIG/`: frozen model, generator and seed settings.
- `original/01_CODE/`: original Paper 1 models, stage runners, Kaggle automation and aggregate evaluators.
- `original/03_STATE/`: dated original experiment contract and study decision chronology.
- `original/06_RESULTS/`: aggregate primary and later-stage analysis outputs.
- `original/REPRODUCE/`: archived reproducibility/reaggregation utilities.
- `postreview/`: baseline, oracle-nuisance, regularization, missingness and 30-DGP simulation scripts and aggregates.
- `corrective/`: fixed-DGP resplitting, clinical adjustment and comparative neural experiments, including per-seed aggregates and training-budget records.
- `original/03_STATE/LOCKED_SPLIT_ROW_INDICES.json`: deterministic 0-based row positions for the original 441/147/148 TRAIN/DEV/TEST split (not participant IDs).

## Computational use

Create separate Python environments for the archived original workflow (`original/requirements.txt`) and the subsequent analyses (`postreview/requirements_postreview.txt`, `corrective/requirements_corrective.txt`). The archived requirements describe the recorded software dependencies; machine-specific CPU/GPU builds can affect bitwise identity.

Run `python PREPARE_PRIVATE_RUNTIME.py` to populate an isolated runtime tree, then reconstruct the public-data matrix there using the original code and source files. Use the `download_public_data.py` and `prepare_ispy2_core_data.py` scripts from the original `01_CODE/scripts` directory and verify the resulting dimensions and manifest before running models. Original pipelines were executed in Kaggle; the archive preserves their stage-specific automation. Local regeneration requires the original Python dependencies and privately reconstructed GEO data. No Kaggle username, token or API secret is stored in this archive.

Once extracted, run `python VERIFY_RELEASE.py` to check content against `MANIFEST_SHA256.csv`. Compare saved aggregates with `original/06_RESULTS` and the corresponding post-review and corrective `results` directories. Original and later studies differ in DGP construction and seed grids and should not be pooled as one prespecified confirmation experiment.

## Interpretation

The original benchmark used five DGP seeds crossed with three neural seeds on one cohort split. Post-review classical experiments used 30 DGP seeds and multiple splits, but split-dependent preprocessing also modified generated CATE; the later fixed-truth study held each DGP and TEST cohort fixed while resplitting TRAIN/DEV. The later neural comparison used 12 DGP seeds per regime, one learner seed, and similar deployed model capacity but unequal total optimization effort. Results are therefore conditional on the stated designs and are not independent external clinical validation.

The `RUN_RESUME_PAPER1_PORTABLE.cmd` launcher starts the post-review orchestration only after the local source matrix has been reconstructed in `postreview/source_snapshot/02_DATA/processed`. Stage-specific Kaggle automation retains additional account and environment prerequisites.

## Additional post-review verification

`diagnostics/` includes a standalone Python script for reconstructing the original 675 archived method-by-run metrics from private preserved TEST prediction arrays; ten-bin conditional-bootstrap calibration intervals for X, T and CM-OSR; and Stage 7B oracle-benefit gate confusion matrices computed from archived DEV predictions. No individual prediction records are distributed in this release. The summary `reconstruction_validation.json` records that all 675 archived prediction-based metrics are within absolute tolerance 1e-6 plus relative tolerance 1e-3. This analysis does not constitute independently rerunning model training.

To regenerate the diagnostics, run `python diagnostics/b01_new_diagnostics.py --archive /path/to/PRIVATE_B01_POST_REVIEW_2026.zip --out /path/to/diagnostics_results`. The private input archive should contain the original stage-4 individual predictions and Stage 7B DEV prediction/decision tables under `source_snapshot/`. The analysis script never modifies the source archive.

`diagnostics/COMPARE_INDEPENDENT_RERUN.py` is supplied for comparing future independently trained output aggregates with the frozen results. It requires a genuinely regenerated original-stage `06_RESULTS` folder; metric reconstruction alone does not establish gate stability after retraining. The comparator checks both scientific gate decisions and reported numeric results under the stated tolerance.
